# SOP_Build
This is the SOP player creation Repo and is where all base players will reside 
